<!doctype html>
<html lang="ru">
<body>
<div class="container d-flex" style="background-color: #23cbff">

    <label>Телефон регистратуры:89041402083</label>
</div>
</body>
</html>